<?php 
$con=mysqli_connect("localhost","root","","hoteli") or die('DATABASE connection failed');

?>